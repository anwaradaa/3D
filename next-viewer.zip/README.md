# Next Viewer

A modern 3D viewer application built with Next.js and Three.js, designed for displaying 3D models with high-quality rendering and interactive camera controls.

## Features

- **3D Scene Rendering**: High-performance rendering with Three.js
- **Resource Management**: Efficient loading and management of 3D models (GLB/GLTF) and HDR environment maps
- **Orbit Controls**: Interactive camera manipulation with smooth transitions
- **Environment Mapping**: HDR environment maps for realistic lighting and reflections
- **Loading Indicators**: Visual feedback during resource loading
- **Responsive Design**: Adapts to different screen sizes
- **TypeScript Support**: Full type safety throughout the codebase
- **Component Architecture**: Clean separation of concerns with modular components

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/next-viewer.git
   cd next-viewer
   ```

2. Install dependencies:
   ```bash
   npm install
   # or
   yarn install
   # or
   pnpm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   # or
   yarn dev
   # or
   pnpm dev
   ```

4. Open [http://localhost:3000](http://localhost:3000) with your browser to see the application.

## Project Structure

- `src/app-3d/`: Core 3D rendering functionality
  - `core/`: Core components and utilities
    - `BasicOrbitViewer.ts`: Base viewer with orbit controls and scene management
    - `ResourceManager.ts`: Handles loading and managing 3D resources
  - `view/`: View components
    - `Viewer.ts`: Extends BasicOrbitViewer with application-specific configuration
  - `Controller.ts`: Main controller that coordinates the viewer and resource management
- `src/components/`: React components
  - `ViewerComponent.tsx`: React component that integrates the 3D viewer
  - `LoaderComponent.tsx`: Loading indicator component
- `src/containers/`: Layout containers
  - `MainContainer.tsx`: Main container for the application layout
- `src/app/`: Next.js app directory
  - `page.tsx`: Main page component
  - `layout.tsx`: Root layout component

## Usage

### Basic Usage

```tsx
import { ViewerComponent } from '../components';

const MyComponent = () => {
  return (
    <div style={{ width: '100%', height: '100vh' }}>
      <ViewerComponent />
    </div>
  );
};
```

### Resource Management

The application uses a ResourceManager to handle loading and managing 3D resources:

```tsx
// Define resources
const modelResource = {
  id: 'my-model',
  type: 'glb',
  url: '/path/to/model.glb'
};

const hdrResource = {
  id: 'environment',
  type: 'hdr',
  url: '/path/to/environment.hdr'
};

// Build the scene with the specified resources
controller.build(modelResource, hdrResource)
  .then(() => {
    console.log('Resources loaded successfully');
  });
```

## Architecture

The application follows a clean architecture pattern:

1. **Controller**: Manages the viewer and resources, handles the render loop
2. **Viewer**: Extends BasicOrbitViewer with application-specific configuration
3. **ResourceManager**: Handles loading and managing 3D resources
4. **React Components**: Integrate the 3D viewer into the React application

## Build for Production

```bash
npm run build
# or
yarn build
# or
pnpm build
```

Then start the production server:

```bash
npm run start
# or
yarn start
# or
pnpm start
```

## Learn More

To learn more about the technologies used in this project:

- [Next.js Documentation](https://nextjs.org/docs)
- [Three.js Documentation](https://threejs.org/docs/)
- [React Documentation](https://reactjs.org/docs/getting-started.html)
- [TypeScript Documentation](https://www.typescriptlang.org/docs/)
